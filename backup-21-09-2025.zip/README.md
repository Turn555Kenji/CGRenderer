# CGRenderer
Simple graphics renderer made using Qt.
